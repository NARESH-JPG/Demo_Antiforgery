﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Demo_AntiforgeryToken_MVC.Models
{
    public class StudentDetailsModel
    {
        [Key]
        public int StudentID { get; set; }
        [Required (ErrorMessage ="Enter Your StudentID")]
        public string Name { get; set; }
        [Required(ErrorMessage ="Enter Your Name")]
        public string Address { get; set; }
        [Required(ErrorMessage ="Enter Your Average")]
        public string Division { get; set; }
       

    }
}
