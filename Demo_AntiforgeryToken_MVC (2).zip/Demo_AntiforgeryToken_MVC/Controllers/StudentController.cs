﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Demo_AntiforgeryToken_MVC.Models;

namespace Demo_AntiforgeryToken_MVC.Controllers
{
    public class StudentController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }


        [HttpGet]
        public IActionResult StudentInfo()
        {
            return View();
        }


        [HttpPost]
        public IActionResult StudentInfo(StudentDetailsModel objSd)
        {
            return View(objSd);
        }
    }
}
